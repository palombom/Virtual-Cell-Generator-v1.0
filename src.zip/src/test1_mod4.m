function [faces_final, vertices_final, bottom_final, top_final, normal_v, plane_x, plane_y] = test1_mod4(node0, node1,radius,noPoints,noSectors,plotflag)

%% Setup the intial values

theta = linspace(0,2*pi,noPoints);

%% Create the X and Y vectors for cylinder of generic orientation

P=node0+1+node1+1;

R = cross(P-node0, node1-node0);
S = cross(R, node1-node0);

u1 = R(1)/norm(R);
u2 = R(2)/norm(R);
u3 = R(3)/norm(R);

v1 = S(1)/norm(S);
v2 = S(2)/norm(S);
v3 = S(3)/norm(S);

w = node1-node0;
w1 = w(1)/norm(w);
w2 = w(2)/norm(w);
w3 = w(3)/norm(w);

t = linspace(0,1,noSectors);


normal_v = w./norm(w);
plane_x = R./norm(R);
plane_y = S./norm(S);

% Suppose the axis goes through the point (X0,Y0,Z0) and lies in the
% direction of the unit vector w; further suppose that u and v are unit
% vectors that are (1) mutually perpendicular and (2) are perpendicular
% to the axis.  Parametric equations for the cylindrical surface are

for ss=1:length(t)-1
   
    faces = [];
    vertices=[];
    bottom=[];
    top=[];

    rr=rand(3,1);
    
    r=radius;
    
%% create matrix of bottom points

x = node0(1) + r.*cos(theta).*u1 + r.*sin(theta).*v1 + t(ss).*norm(w).*w1;
y = node0(2) + r.*cos(theta).*u2 + r.*sin(theta).*v2 + t(ss).*norm(w).*w2;
z = node0(3) + r.*cos(theta).*u3 + r.*sin(theta).*v3 + t(ss).*norm(w).*w3;

bottom = [x',y',z'];
bottom_final(:,:,ss) = bottom;

%% create matrix of top points

x = node0(1) + r.*cos(theta).*u1 + r.*sin(theta).*v1 + t(ss+1).*norm(w).*w1;
y = node0(2) + r.*cos(theta).*u2 + r.*sin(theta).*v2 + t(ss+1).*norm(w).*w2;
z = node0(3) + r.*cos(theta).*u3 + r.*sin(theta).*v3 + t(ss+1).*norm(w).*w3;

top = [x',y',z'];
top_final(:,:,ss) = top;

%% Create faces and vertices matrix

%create the vertices matrix
vertices = [bottom;top];
vertices_final(:,:,ss) = vertices;

%Create the faces matrix: 'Top' triangles
faces = [(1:noPoints)',(noPoints+1:2*noPoints)',((noPoints+1:2*noPoints)+1)'];
%replace the last to one since it is out of bounds
faces(end,3) = 1;
% Add 'Bottom Triangles'
faces = [faces;...
    (1:noPoints)',((noPoints+1:2*noPoints)+1)', ((1:noPoints)+1)'];

%replace the last to one since it is wrong
faces(end,2) = 1;
faces(end,3) = noPoints+1;

faces_final(:,:,ss)=faces;
%% Use patch to plot

if plotflag
    patch('faces',faces,'vertice',vertices,'facecolor',[0 1 0],'edgecolor',[1 0 0],'facealpha',0.3); hold on
    axis('equal')
    view(0,90);
end

end

end