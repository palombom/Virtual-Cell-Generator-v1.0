function signal_plot = MISST_analysis_2(B, TM, cell_num, foldername, filename, Rsoma, Rbranch, fsoma, di, Npoints)

addpath(genpath('/Users/marcop/Desktop/Current_Projects/Julien_DDE/MISST'))
addpath(genpath('/Users/marcop/Desktop/Current_Projects/MIG_project'))

%% Create the dPFG protocol with the same parameters as in Drobnjak et al 2011:

%Npoints = 9;
smalldel = 0.0045; % sec
delta = 0.030; % sec
%tm = 0.0055; % sec
%tm = 0.0295; % sec
%tm = 0.100; % sec

tm = TM;

GAMMA = 2.675987E8;

b = B*1e6; %s/m2

G = sqrt(b./(delta-smalldel/3))./(GAMMA*smalldel); % T/m

protocoldPFG1.pulseseq = 'dPFG';
protocoldPFG1.smalldel = repmat(smalldel,1,Npoints);
protocoldPFG1.G = repmat(G,1,Npoints); 
protocoldPFG1.delta = repmat(delta,1,Npoints);
protocoldPFG1.theta = repmat(pi/2,1,Npoints);
protocoldPFG1.phi = zeros(1,Npoints); % first gradient along x direction
protocoldPFG1.theta1 = repmat(pi/2,1,Npoints);
% second gradient rotating in x-y plane
protocoldPFG1.phi1 = linspace(0,2*pi,Npoints); 
protocoldPFG1.tm = repmat(tm,1,Npoints);
tau = 1e-04;
protocoldPFG1.tau = tau; 

%% Create the GEN protocol:

%protocolGEN = protocoldPFG1;
protocolGEN.pulseseq = 'GEN';
protocolGEN.G = wave_form(protocoldPFG1);
protocolGEN.tau = tau;
protocolGEN.totalmeas = size(protocolGEN.G,1);

% schemefile = 'test_myDDE.scheme';
% 
% ProtocolToScheme(protocolGEN, schemefile);

tau = 1e-04;
protocoldPFG1.tau = tau; 
protocolGEN.pulseseq = 'GEN';
protocolGEN.G = wave_form(protocoldPFG1);
protocolGEN.tau = tau;
protocolGEN.totalmeas = size(protocolGEN.G,1);

%% Display the gradient waveform along x direction for the first pulse sequence:

% figure();
% G_plot = protocolGEN.G(1,1:3:end);
% plot((0:tau:(length(G_plot)-1)*tau)*1E3,G_plot*1000,'LineWidth',2)
%  xlim([0,(length(G_plot)+5)*tau*1E3])
%  ylim([min(G_plot)*1200 max(G_plot)*1200])
%  set(gca,'FontSize',16);
%  xlabel('time (ms)','FontSize',16);
%  ylabel('Gx (mT/m)','FontSize',16);
%  title('Gradient wavefor for \phi = 0')

 %% Prepare substrate's mesh

%cell_num = 26;

%foldername = 'substrates_JV_3/';

%filename = [foldername 'astrocylinder_' num2str(cell_num) '_SI.ply'];

[vertex,~] = read_ply(filename);

substrate_charact = importdata([foldername 'substrates_characteristics.dat']);

 %% Investigate Tissue characteristic length
 
% [X,Y,Z] = sphere(25);
% X = X(:);
% Y = Y(:);
% Z = Z(:);
% r = unique([X Y Z],'row');
%  
% TT = zeros(size(r,1),1);
% 
% h=waitbar(0,'Measuring effective soma radius...');
% 
% for i = 1:size(r,1)
%     
%     waitbar(i/size(r,1))
%     
%     [flag, t, lambda{i}] = ray_mesh_intersect([0 0 0], r(i,:), vertex, face);
%     if isempty(t(flag==1))==0
%         TT(i) = min(t(flag==1));
%     else
%         TT(i) = inf;
%     end
%     
% end
% 
% close(h)
% 
% reff = min(TT);

rth = Rsoma.*1e-6;
fsomath = fsoma;

reff = min( [max(vertex(abs(vertex(:,1))<=rth,1)) - min(vertex(abs(vertex(:,1))<=rth,1)) ...
             max(vertex(abs(vertex(:,2))<=rth,2)) - min(vertex(abs(vertex(:,2))<=rth,2)) ...
             max(vertex(abs(vertex(:,3))<=rth,3)) - min(vertex(abs(vertex(:,3))<=rth,3))] ) / 2;
         
kappa = reff/rth;

fsomaeff = fsomath.*kappa^3;

%% Add tissue model

% Infinitely Long Cylinder

% model.name = 'Cylinder';
% di = 2E-9; % intrinsic diffusivity
% rad = 5E-6; % cylinder radius
% % angles in spherical coordinates describing the cylinder orientation; 
% theta = 0; % angle from z axis
% phi = 0; % azimuthal angle
% model.params = [ di rad theta phi]; 

%% Compute diffusion signal for Sphere

model.name = 'Sphere';

%di = 0.5E-9; % intrinsic diffusivity
rad = reff; % sphere radius
%di = 0.5E-9; % intrinsic diffusivity
%rad = 5.706348*1E-6/2; % sphere radius

model.params = [ di rad ];

protocolGEN = MMConstants(model,protocolGEN);

signal_sphere = SynthMeas(model,protocolGEN);

%% Compute diffusion signal for AstroCylinders

model.name = 'AstroCylinders';
%di = 0.5E-9; % intrinsic diffusivity
r = Rbranch.*1e-6;
model.params = [di r];

protocolGEN = MMConstants(model,protocolGEN);

signal_astrocylinders = SynthMeas(model,protocolGEN);

%% Plot the diffusion signal as a function of the angle between the two gradients (Fig. 1b)
signal_plot = fsomath.*signal_sphere + (1-fsomath).*signal_astrocylinders;
%signal_plot = signal_sphere;
%figure();
% hold on;  
% plot(linspace(0,2*pi,Npoints),signal_plot(:,1),'-','LineWidth',2,'MarkerSize',12);

end
