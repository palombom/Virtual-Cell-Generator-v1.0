function writeInitPositions(positions, fname)
%Write intial positions for camino to a .dat file
%
% positions should be nx3 array of intial positions

noSpins = size(positions, 1);

ext = fname(end-3:end);
if ext ~= '.dat'
    fname = strcat(fname, '.dat');
end

fid = fopen(fname,'w+');

fprintf(fid,'%d\n',noSpins);
fprintf(fid,'%g %g %g\n', positions');

fclose(fid);