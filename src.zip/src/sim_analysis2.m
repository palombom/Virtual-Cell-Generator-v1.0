function signal_plot = sim_analysis2(B, smalldel, delta, TM, theta0, phi0, cell_num, traj, Npoints)

addpath(genpath('/Users/marcop/Desktop/Current_Projects/Julien_DDE/MISST'))
addpath(genpath('/Users/marcop/Desktop/Current_Projects/MIG_project'))

%% Create the dPFG protocol with the same parameters as in Drobnjak et al 2011:

%Npoints = 9;
%smalldel = 0.0045; % sec
%delta = 0.030; % sec
%tm = 0.0055; % sec
%tm = 0.0295; % sec
%tm = 0.100; % sec

tm = TM;

GAMMA = 2.675987E8;

b = B*1e6; %s/m2

G = sqrt(b./(delta-smalldel/3))./(GAMMA*smalldel); % T/m

protocoldPFG1.pulseseq = 'dPFG';
protocoldPFG1.smalldel = repmat(smalldel,1,Npoints);
protocoldPFG1.G = repmat(G,1,Npoints); 
protocoldPFG1.delta = repmat(delta,1,Npoints);

protocoldPFG1.theta = repmat(theta0,1,Npoints);
%protocoldPFG1.phi = zeros(1,Npoints); % first gradient along x direction
protocoldPFG1.phi = repmat(phi0,1,Npoints);

protocoldPFG1.theta1 = repmat(theta0,1,Npoints);
% second gradient rotating in x-y plane
protocoldPFG1.phi1 = linspace(0,2*pi,Npoints);

protocoldPFG1.tm = repmat(tm,1,Npoints);
tau = 1e-04;
protocoldPFG1.tau = tau; 

%% Create the GEN protocol:

%protocolGEN = protocoldPFG1;
protocolGEN.pulseseq = 'GEN';
protocolGEN.G = wave_form(protocoldPFG1);
protocolGEN.tau = tau;
protocolGEN.totalmeas = size(protocolGEN.G,1);

schemefile = 'test_myDDE.scheme';

ProtocolToScheme(protocolGEN, schemefile);

tau = 1e-04;
protocoldPFG1.tau = tau; 
protocolGEN.pulseseq = 'GEN';
protocolGEN.G = wave_form(protocoldPFG1);
protocolGEN.tau = tau;
protocolGEN.totalmeas = size(protocolGEN.G,1);

 %% Prepare substrate's mesh

foldername = 'substrates_JV_2/';

filename = [foldername 'astrocylinder_' num2str(cell_num) '_SI.ply'];

[vertex,~] = read_ply(filename);

substrate_charact = importdata([foldername 'substrates_characteristics.dat']);

rth = substrate_charact.data(cell_num,5).*1e-6;
fsomath = substrate_charact.data(cell_num,6);

reff = min( [max(vertex(abs(vertex(:,1))<=rth,1)) - min(vertex(abs(vertex(:,1))<=rth,1)) ...
             max(vertex(abs(vertex(:,2))<=rth,2)) - min(vertex(abs(vertex(:,2))<=rth,2)) ...
             max(vertex(abs(vertex(:,3))<=rth,3)) - min(vertex(abs(vertex(:,3))<=rth,3))] ) / 2;
         
kappa = reff/rth;

fsomaeff = fsomath.*kappa^3;

t_equilibration = 0.0;

[S, Gx, Gy, Gz] = compute_signal_from_schemefile(traj, schemefile,1,t_equilibration); 

signal_plot = S;

end
