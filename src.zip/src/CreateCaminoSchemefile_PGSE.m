function CreateCaminoSchemefile_PGSE(scheme_folder, scheme_filename, B, smalldel, delta, Ndirections)
    

    disp('    Creating and saving SDE sequence protocol')
    protocol_PGSE = struct;
    protocol_PGSE.pulseseq = 'PGSE';
    protocol_PGSE.testrategy = 'fixed';
    protocol_PGSE.roots_sphere = BesselJ_RootsSphere(100);
    protocol_PGSE.roots_cyl = BesselJ_RootsCyl(100);
    
    nbval = length(B);
    tau = 1E-4;

    dir = ParticleSampleSphere('N',Ndirections);
    bvec = repmat(dir, [nbval 1]);
    bval = repmat(B, [1 Ndirections]);

    GAMMA = 2.675987E8;
    for k=1:nbval*Ndirections
        protocol_PGSE.G(1,k) = sqrt(bval(k).*1e9./(delta-smalldel/3))./(GAMMA.*smalldel);
        protocol_PGSE.grad_dirs(k,:) = bvec(k,:);
    end

    protocol_PGSE.smalldel = repmat(smalldel,[1 nbval*Ndirections]);
    protocol_PGSE.delta = repmat(delta,[1 nbval*Ndirections]);
    protocol_PGSE.tau = tau;

    fid = fopen([scheme_folder '/' scheme_filename '_details.dat'],'w');
    fprintf(fid, 'Bval(sec/mm2)\t DELTA(sec)\t SMALLDEL(sec)\t tau(sec) \n');

    for i = 1:numel(B)
        for j = 1:numel(protocol_PGSE.delta)
            for k =1:numel(protocol_PGSE.smalldel)
                fprintf(fid, '%d\t %d\t %d\t %d\t ', B(i), protocol_PGSE.delta(j), protocol_PGSE.smalldel(k), tau);
                fprintf(fid, '\n');
            end
        end
    end

    protocolGEN.pulseseq = 'GEN';
    protocolGEN.G = wave_form(protocol_PGSE);
    protocolGEN.tau = tau;
    protocolGEN.totalmeas = nbval*Ndirections;
    
    ProtocolToScheme(protocolGEN, [scheme_folder '/' scheme_filename '.scheme']);
    
    figure();
    G_plot_i = protocolGEN.G(1,1:3:end);
    plot((0:tau:(length(G_plot_i)-1)*tau)*1E3,G_plot_i*1000,'LineWidth',2);
    xlim([0,(length(G_plot_i)+5)*tau*1E3])
    ylim([min(G_plot_i)*1200 max(G_plot_i)*1200])
    set(gca,'FontSize',16);
    xlabel('time (ms)','FontSize',16);
    ylabel('Gx (mT/m)','FontSize',16);
    title('PGSE - Gradient wavefor for b = 200')
    savefig([scheme_folder '/' scheme_filename '.fig']);
    
end
