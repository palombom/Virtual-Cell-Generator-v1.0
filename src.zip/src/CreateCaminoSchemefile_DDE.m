function [protocoldPFG1, protocolGEN] = CreateCaminoSchemefile_DDE(scheme_folder, scheme_filename, B, smalldel, delta, TM, Npoints, Ndirections)

    phi = linspace(0,pi,Npoints);

    V1 = ParticleSampleSphere('N',Ndirections*2);

    V_odd = V1(1:2:end,:);
    V_even = V1(2:2:end,:);

    rotV = cross(V_odd,V_even,2);
    rotV = rotV./sqrt(rotV(:,1).^2 + rotV(:,2).^2 + rotV(:,3).^2);

    phi1 = zeros(Ndirections,numel(phi));
    phi2 = zeros(Ndirections,numel(phi));
    theta1 = zeros(Ndirections,numel(phi));
    theta2 = zeros(Ndirections,numel(phi));

    for i=1:numel(phi)
        for j=1:size(rotV,1)
            rotationVector = phi(i) .* rotV(j,:);
            rotationMatrix = rotationVectorToMatrix(rotationVector);
            G1 = V_odd(j,:);
            G2 = rotationMatrix*V_odd(j,:)';
            [phi1(j,i),theta1(j,i)] = cart2sph(G1(1),G1(2),G1(3));
            [phi2(j,i),theta2(j,i)] = cart2sph(G2(1),G2(2),G2(3));
        end
    end

    fid = fopen([scheme_folder '/' scheme_filename '_details.dat'],'w');
    fprintf(fid, 'Bval(sec/mm2)\t DELTA(sec)\t SMALLDEL(sec)\t TM(sec)\t phi(rad) \n');

    for i = 1:numel(B)
        for j = 1:numel(delta)
            for k =1:numel(smalldel)
                for l = 1:numel(TM)
                    fprintf(fid, '%d\t %d\t %d\t %d\t ', B(i), delta(j), smalldel(k), TM(l));
                    for m = 1:numel(phi)
                        fprintf(fid, '%d\t ', phi(m));
                    end
                    fprintf(fid, '\n');
                end
            end
        end
    end

    [protocoldPFG1, protocolGEN] = camino_scheme_generation(scheme_folder, scheme_filename, B, smalldel, delta, TM, theta1, phi1, theta2, phi2);

end

function [protocoldPFG1, protocolGEN] = camino_scheme_generation(folder, filename, B, SMALLDEL, DELTA, TM, theta1, phi1, theta2, phi2)
    
    %% Create the dPFG protocol with the same parameters as in Drobnjak et al 2011:

    disp('    Creating and saving DDE sequence protocol');

    Ndirections = size(theta1,1);
    Npoints = size(theta1,2);

    protocoldPFG1 = struct;
    protocoldPFG1.pulseseq = 'dPFG';
    protocoldPFG1.smalldel = [];
    protocoldPFG1.G = [];
    protocoldPFG1.delta = [];
    protocoldPFG1.theta = [];
    protocoldPFG1.phi = [];
    protocoldPFG1.theta1 = [];
    protocoldPFG1.phi1 = [];
    protocoldPFG1.phi1 = [];
    protocoldPFG1.tm = [];

    for bi = 1:numel(B)
        for Di = 1:numel(DELTA)
            for di = 1:numel(SMALLDEL)
                for tmi = 1:numel(TM)
                    for diri=1:Ndirections

                        tm = TM(tmi);
                        b = B(bi)*1e6; %s/m2
                        delta = DELTA(Di);
                        smalldel = SMALLDEL(di);

                        GAMMA = 2.67E8;
                        G = sqrt(b./(delta-smalldel/3))./(GAMMA*smalldel); % T/m

                        protocoldPFG1.theta = [protocoldPFG1.theta, theta1(diri,:)];
                        protocoldPFG1.phi = [protocoldPFG1.phi, phi1(diri,:)]; % first gradient along x direction
                        protocoldPFG1.theta1 = [protocoldPFG1.theta1, theta2(diri,:)];
                        % second gradient rotating in x-y plane
                        protocoldPFG1.phi1 = [protocoldPFG1.phi1, phi2(diri,:)];

                        protocoldPFG1.smalldel = [protocoldPFG1.smalldel repmat(smalldel,[1 Npoints])];
                        protocoldPFG1.G = [protocoldPFG1.G repmat(G,1,Npoints)];
                        protocoldPFG1.delta = [protocoldPFG1.delta repmat(delta, [1 Npoints])];
                        protocoldPFG1.tm = [protocoldPFG1.tm repmat(tm,[1 Npoints])];
                    end
                end
            end
        end
    end

    % Add one B = 0 at the end

    protocoldPFG1.smalldel = [protocoldPFG1.smalldel SMALLDEL(1)];
    protocoldPFG1.G = [protocoldPFG1.G 1e-9];
    protocoldPFG1.delta = [protocoldPFG1.delta DELTA(1)];

    protocoldPFG1.theta = [protocoldPFG1.theta pi/2];
    protocoldPFG1.phi = [protocoldPFG1.phi 0]; % first gradient direction
    protocoldPFG1.theta1 = [protocoldPFG1.theta1 pi/2];
    % second gradient 
    protocoldPFG1.phi1 = [protocoldPFG1.phi1 0];

    protocoldPFG1.tm = [protocoldPFG1.tm TM(1)];

    tau = 1e-04;
    protocoldPFG1.tau = tau; 

    %% Create the GEN protocol:

    protocolGEN.pulseseq = 'GEN';
    A = wave_form(protocoldPFG1);
    % Add G=0 at the beginning
    protocolGEN.G = [repmat(0, [size(A,1) 100*3]) A];

    protocolGEN.tau = tau;
    protocolGEN.totalmeas = size(protocolGEN.G,1);

    ProtocolToScheme(protocolGEN, [folder '/' filename '.scheme']);

     % display gradient waveform in the case  phi1=0%%
      figure();
      axis_labels = {'Gx (mT/m)', 'Gy (mT/m)', 'Gz (mT/m)'};
      for i=1:3
          for j=1:5
              G_plot = protocolGEN.G(j,i:3:end);
              subplot(3,1,i), hold on, plot((0:tau:(length(G_plot)-1)*tau)*1E3,G_plot*1000,'LineWidth',2)
          end
       set(gca,'FontSize',16);
       xlabel('time (ms)','FontSize',16);
       ylabel(axis_labels{i},'FontSize',16);
       title('DDE - Gradient waveform')
      end
      savefig([folder '/' filename '.fig']);
  
end
