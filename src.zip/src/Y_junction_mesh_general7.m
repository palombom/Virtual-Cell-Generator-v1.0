function [faces, vertices, junction_volume, tot_branch_volume] = Y_junction_mesh_general7(P, Node_Branch, Relation, radius,noPoints,noSections)

% Relation = 0 for Parent Branches and Relation = 1 for Daughter Branches

%% Defining the skeleton

%% Meshing the branches

n_P = size(P,1);

n_branch = size(Node_Branch,1);

tot_branch_volume = 0;

branch_vec = P(Node_Branch(:,2),:) - P(Node_Branch(:,1),:);

geometry = struct;

y = zeros(n_branch,1);

v1 = branch_vec(2,:)./norm(branch_vec(2,:));
v2 = branch_vec(3,:)./norm(branch_vec(3,:));

theta = acos( dot(v1,v2) );

yy = (2.*radius(2)+2.*radius(3))./(2.*sin(theta/2));

v_sphere=zeros(n_branch,3);

for i=1:n_branch
    
    if Relation(i)==0

        
        %[geometry(i).faces_final, geometry(i).vertices_final, ~, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = cylGen(P(Node_Branch(i,1),:),P(Node_Branch(i,2),:),radius(i),noPoints,noSections,0,0,0);
        %[geometry(i).faces_final, geometry(i).vertices_final, ~, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = cylGen(P(Node_Branch(i,1),:),P(Node_Branch(i,2),:),radius(i),noPoints,noSections,0,0,0);
        [geometry(i).faces_final, geometry(i).vertices_final, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = test1_mod4(P(Node_Branch(i,1),:),P(Node_Branch(i,2),:),radius(i),noPoints,noSections,0);
        tmp = unique([geometry(i).bottom_final(:,:,1); geometry(i).top_final(:,:,end)],'row');
        DT_tmp = delaunayTriangulation(tmp);
        [~, tmp_branch_volume] = convexHull(DT_tmp);
        tot_branch_volume = tot_branch_volume + tmp_branch_volume;
    else
        
        v1 = branch_vec(i,:)./norm(branch_vec(i,:));
        
        P_tmp = P(Node_Branch(i,1),:) + yy.*v1;
        
        v_sphere(i,:) = P(Node_Branch(i,1),:) + yy.*v1;
        
        %[geometry(i).faces_final, geometry(i).vertices_final, ~, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = cylGen(P_tmp,P(Node_Branch(i,2),:),radius(i),noPoints,noSections,0,0,0);
        [geometry(i).faces_final, geometry(i).vertices_final, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = test1_mod4(P_tmp,P(Node_Branch(i,2),:),radius(i),noPoints,noSections,0);

        tmp = unique([geometry(i).bottom_final(:,:,1); geometry(i).top_final(:,:,end)],'row');
        DT_tmp = delaunayTriangulation(tmp);
        [~, tmp_branch_volume] = convexHull(DT_tmp);
        tot_branch_volume = tot_branch_volume + tmp_branch_volume;
        
    end
    
end


%% Meshing the Y junction

XX = [];

for i=1:n_branch
    
    if Relation(i)==0
        
        XX = [XX; geometry(i).top_final(1:end-1,:,end)];
        
        
    else
        
        XX = [XX; geometry(i).bottom_final(1:end-1,:,1)];
        
    end
    
end

   %[Xs, Ys, Zs] = sphere(10);   
   %SPHERE = unique([Xs(:), Ys(:), Zs(:)],'rows');
  % XX = [XX; radius(1).*SPHERE + v_sphere(2,:); radius(1).*SPHERE + v_sphere(3,:)];

DT=delaunayTriangulation(XX);
[T, junction_volume] = convexHull(DT);
Xb = DT.Points;

condition = ones(size(T,1),1);

k=1;

for i=1:n_branch
    
    if Relation(i)==0
        
        interface = geometry(i).top_final(1:end-1,:,end);
        
    else
        
        interface = geometry(i).bottom_final(1:end-1,:,1);
        
    end
    
    kini= k;
    kfin=k+size(interface,1);
    
    cc = sum(T>=kini & T<kfin,2);
    
    condition = condition & (~(cc==3));
    
    k=kfin;
    
end

vertices=Xb;
faces=T(condition,:);

% figure, hold on
% patch('Faces',faces,'Vertices',vertices,'FaceColor',[0 0 1], 'FaceAlpha', 1)
% hold on, plot3(vertices(:,1),vertices(:,2),vertices(:,3),'o')

for k=1:n_branch
    
    if Relation(k)==0
        
        for i=1:size(geometry(k).vertices_final,3)
        
        no_vertex = size(vertices,1);
        vertices = [vertices; geometry(k).vertices_final(:,:,i)];
        faces = [faces; geometry(k).faces_final(:,:,i)+no_vertex];
        
        end
        
    else
        
        for i=1:size(geometry(k).vertices_final,3)
        
        no_vertex = size(vertices,1);
        vertices = [vertices; geometry(k).vertices_final(:,:,i)];
        faces = [faces; geometry(k).faces_final(:,:,i)+no_vertex];
        
        end
    end
    
end

% patch('Faces',faces,'Vertices',vertices,'FaceColor',[0 1 0], 'FaceAlpha', 0.5)

end