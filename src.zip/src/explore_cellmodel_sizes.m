function [rmin_soma, rmax_soma, rmin_branch, rmax_branch] = explore_cellmodel_sizes(filename)

% Read substrate's mesh and SWC representation

disp('  * Calculating Cellular Substrate Effective Characteristics:')

%cell_num = 1;

%foldername = '/Users/marcop/Desktop/Current_Projects/Julien_DDE/substrates_Andrada_with_without_exchange/instance_1/';

% filename = [foldername 'cellmodel_' num2str(cell_num)];
if exist([filename '_closed.ply'],"file")
[vertex,face] = read_ply([filename '_closed.ply']);
else
[vertex,face] = read_ply([filename '.ply']);
end

vert0 = vertex(face(:,1),:);
vert1 = vertex(face(:,2),:);
vert2 = vertex(face(:,3),:);

tree = load_tree([filename '.swc']);
[Xi, Xf, Yi, Yf ,Zi, Zf] = cyl_tree (tree);
DR = ([Xf Yf Zf] - [Xi Yi Zi])./2;
midP = [Xi Yi Zi] + DR;

I = find(sum(abs(midP),2)<=3);
midP(I(2:end),:) = [];
Xi(I(2:end)) = [];
Xf(I(2:end)) = [];
Yi(I(2:end)) = [];
Yf(I(2:end)) = [];
Zi(I(2:end)) = [];
Zf(I(2:end)) = [];


% Investigate Tissue characteristic length

nRay = 10;

[X,Y,Z] = sphere(nRay);
r = unique([X(:) Y(:) Z(:)],'row');

TT = zeros(size(r,1),size(midP,1));

for j= 1:size(midP,1)
    
%    if sum(midP(j,:)) == 0
    if j==1
        
        [X,Y,Z] = sphere(nRay);
        r = unique([X(:) Y(:) Z(:)],'row');
        
    else
        
        %% Create disc
        [X,Y,Z] = sphere(nRay);
        r = unique([X(:) Y(:) Z(:)],'row');
        noPoints = size(r,1);
        theta = linspace(0,2*pi,noPoints);
        
        node0 = [Xi(j) Yi(j) Zi(j)];
        node1 = [Xf(j) Yf(j) Zf(j)];
        
        P=node0+1+node1+1;
        P(1) = 0;
        R = cross(P-node0, node1-node0);
        if R(1) < 0
            R = -R;
        end
        S = cross(R, node1-node0);
        
        u1 = R(1)/norm(R);
        u2 = R(2)/norm(R);
        u3 = R(3)/norm(R);
        
        v1 = S(1)/norm(S);
        v2 = S(2)/norm(S);
        v3 = S(3)/norm(S);
        
        r=1;
        
        x = r.*cos(theta).*u1 + r.*sin(theta).*v1 ;
        y = r.*cos(theta).*u2 + r.*sin(theta).*v2 ;
        z = r.*cos(theta).*u3 + r.*sin(theta).*v3 ;
        
        r = [x' y' z'];
    end
    for i = 1:size(r,1)        
        
        % [flag, t, ~] = ray_mesh_intersect(midP(j,:), r(i,:), vertex, face);
        [flag, t] = TriangleRayIntersection (midP(j,:), r(i,:), vert0, vert1, vert2);
        if isempty(t(flag==1))==0
            TT(i,j) = min(t(flag==1));
        else
            TT(i,j) = nan;
        end
    end
end

rmin_soma = min(TT(:,1));
rmax_soma = max(TT(:,1));
rmin_branch = mean(min(TT(:,2:end),[],1));
rmax_branch = mean(max(TT(:,2:end),[],1));

end