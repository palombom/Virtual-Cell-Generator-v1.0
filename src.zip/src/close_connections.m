function [] = close_connections(filename)

fp = fopen('tmp.py','w');

fprintf(fp,'import argparse\n');
fprintf(fp,'import bpy\n');
fprintf(fp,'bpy.ops.import_mesh.ply(filepath = "%s" + ".ply")\n', filename);
fprintf(fp,'bpy.ops.object.mode_set(mode=''EDIT'')\n');
fprintf(fp,'bpy.ops.mesh.fill_holes()\n');
fprintf(fp,'bpy.ops.mesh.quads_convert_to_tris(quad_method=''BEAUTY'')\n');
fprintf(fp,'bpy.ops.export_mesh.ply(filepath = "%s" + "_closed.ply")\n',filename);
fprintf(fp,'bpy.ops.object.delete()');
fclose(fp);

command = '/Applications/Blender/blender.app/Contents/MacOS/blender -b -P tmp.py';

%while ~exist([filename '_closed.ply'],'file')

system(command);

%end

delete('tmp.py')

[vertices, faces] = read_ply([filename '_closed.ply']);
vertices = vertices.*1E-6;
plyWrite(vertices,faces,[filename '_closed_IS.ply']);

end

