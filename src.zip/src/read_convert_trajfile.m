function [] = read_convert_trajfile(filename)

traj = LoadCaminoTraj(filename,1);
traj.data = single(traj.data);
save([filename '.mat'],'traj','-v7.3');
delete(filename)

end