
clear all

addpath(genpath('src'))

%B = [2500 5000 10000]; % B value of each single block in sec/mm2
B = 10000; % B value of each single block in sec/mm2
smalldel = 0.0045; % sec
delta = 0.030; % sec
TM = [0.001 0.0055 0.012 0.0295 0.050 0.100 0.150 0.200]; %sec
Npoints = 27;
phi = linspace(0,2*pi,Npoints).*180./pi;


foldername = 'schemefiles_new3';

mkdir(foldername)

fid = fopen([foldername '/schemefile_details.dat'],'w');
fprintf(fid, 'Bval(sec/mm2)\t DELTA(sec)\t SMALLDEL(sec)\t TM(sec)\t phi(deg) \n');

for i = 1:numel(B)
    for j = 1:numel(delta)
        for k =1:numel(smalldel)
            for l = 1:numel(TM)
                fprintf(fid, '%d\t %d\t %d\t %d\t ', B(i), delta(j), smalldel(k), TM(l));
                for m = 1:numel(phi)

                    %camino_scheme_generation([foldername '/schemefile_B_' num2str(i) '_TM_' num2str(j)], B(i), smalldel, delta, TM(j), Npoints)
                    
                    fprintf(fid, '%d\t ', phi(m));
                    
                end
                
                fprintf(fid, '\n');
                
            end
        end
    end
end

camino_scheme_generation([foldername '/schemefile'], B, smalldel, delta, TM, Npoints);

function [] = camino_scheme_generation(filename, B, SMALLDEL, DELTA, TM, Npoints)

% addpath(genpath('/Users/marcop/Desktop/Current_Projects/Julien_DDE/MISST'))
% addpath(genpath('/Users/marcop/Desktop/Current_Projects/MIG_project'))

%% Create the dPFG protocol with the same parameters as in Drobnjak et al 2011:

fprintf('Defining sequence parameters...');

%Npoints = 27;
%smalldel = 0.0045; % sec
%delta = 0.030; % sec
%tm = 0.0055; % sec
%tm = 0.0295; % sec
%tm = 0.200; % sec


protocoldPFG1 = struct;
protocoldPFG1.pulseseq = 'dPFG';
protocoldPFG1.smalldel = [];
protocoldPFG1.G = [];
protocoldPFG1.delta = [];
protocoldPFG1.theta = [];
protocoldPFG1.phi = [];
protocoldPFG1.theta1 = [];
protocoldPFG1.phi1 = [];
protocoldPFG1.phi1 = [];
protocoldPFG1.tm = [];

for bi = 1:numel(B)
    for Di = 1:numel(DELTA)
        for di = 1:numel(SMALLDEL)
            for tmi = 1:numel(TM)
                
                tm = TM(tmi);
                b = B(bi)*1e6; %s/m2
                delta = DELTA(Di);
                smalldel = SMALLDEL(di);
                
                GAMMA = 2.675987E8;
                G = sqrt(b./(delta-smalldel/3))./(GAMMA*smalldel); % T/m
                
                protocoldPFG1.smalldel = [protocoldPFG1.smalldel repmat(smalldel,[1 Npoints])];
                protocoldPFG1.G = [protocoldPFG1.G repmat(G,1,Npoints)];
                protocoldPFG1.delta = [protocoldPFG1.delta repmat(delta, [1 Npoints])];
                
                protocoldPFG1.theta = [protocoldPFG1.theta repmat(pi/2,[1 Npoints])];
                protocoldPFG1.phi = [protocoldPFG1.phi zeros(1,Npoints)]; % first gradient along x direction
                protocoldPFG1.theta1 = [protocoldPFG1.theta1 repmat(pi/2,[1 Npoints])];
                % second gradient rotating in x-y plane
                protocoldPFG1.phi1 = [protocoldPFG1.phi1 linspace(0,2*pi,Npoints)];
                
                protocoldPFG1.tm = [protocoldPFG1.tm repmat(tm,[1 Npoints])];
            end
        end
    end
end

% Add one B = 0 at the end

protocoldPFG1.smalldel = [protocoldPFG1.smalldel SMALLDEL(1)];
protocoldPFG1.G = [protocoldPFG1.G 1e-9];
protocoldPFG1.delta = [protocoldPFG1.delta DELTA(1)];

protocoldPFG1.theta = [protocoldPFG1.theta pi/2];
protocoldPFG1.phi = [protocoldPFG1.phi 0]; % first gradient along x direction
protocoldPFG1.theta1 = [protocoldPFG1.theta1 pi/2];
% second gradient rotating in x-y plane
protocoldPFG1.phi1 = [protocoldPFG1.phi1 0];

protocoldPFG1.tm = [protocoldPFG1.tm TM(1)];

tau = 1e-04;
protocoldPFG1.tau = tau; 

%% Create the GEN protocol:

protocolGEN.pulseseq = 'GEN';
protocolGEN.G = wave_form(protocoldPFG1);
protocolGEN.tau = tau;
protocolGEN.totalmeas = size(protocolGEN.G,1);

schemefile = [filename '.scheme'];

ProtocolToScheme(protocolGEN, schemefile);

%display gradient waveform in the case  phi1=0%%
figure();
G_plot = protocolGEN.G(1,1:3:end);
plot((0:tau:(length(G_plot)-1)*tau)*1E3,G_plot*1000,'LineWidth',2)
 xlim([0,(length(G_plot)+5)*tau*1E3])
 ylim([min(G_plot)*1200 max(G_plot)*1200])
 set(gca,'FontSize',16);
 xlabel('time (ms)','FontSize',16);
 ylabel('Gx (mT/m)','FontSize',16);
 title('Gradient waveform')

end

