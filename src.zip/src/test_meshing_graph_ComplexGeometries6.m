
function [vertices,faces,tree, soma_volume, tot_branch_volume, tot_Y_junction_volume] = test_meshing_graph_ComplexGeometries6(filename, method, mean_N_process, sigma_N_process, mean_L_segment, sigma_L_segment, mean_N_branching, sigma_N_branching, mean_angle, dsoma, soma_sampling, soma_smoothing, dbranch, dbranch_sf, seed_rng, sphericity)

[cellgraph, tree, ~, node_degeneration, branch_mat, node_branch_mat, node_mat]=generate_astro_graph_5_nosoma(3, method, mean_N_process, sigma_N_process, mean_L_segment, sigma_L_segment, mean_N_branching, sigma_N_branching, mean_angle, dsoma, soma_sampling, soma_smoothing, dbranch, dbranch_sf, seed_rng);

radius = zeros(cellgraph(1).N_branches,1);

for i=1:cellgraph(1).N_branches
    
    radius(i) = cellgraph(i).radius;
    
end
 
soma_radius = dsoma./2;

noPoints = 5;
noSectors = 2;

vertices = [];
faces = [];

tot_Y_junction_volume = 0;
tot_branch_volume = 0;

for i = 1:size(node_branch_mat,1)
    
    if i == 1
        
        % build the soma
        
        P=zeros(node_degeneration(i)+1,3);
        
        Node_Branch = branch_mat(node_branch_mat(i,:),:);
        
        branch_vec = node_mat(Node_Branch(:,2),:) - node_mat(Node_Branch(:,1),:);
        
        P(1,:)=node_mat(1,:);
        
        for ii=1:node_degeneration(i)
            P(ii+1,:)=node_mat(1,:)+branch_vec(ii,:)./norm(branch_vec(ii,:)).*soma_radius.*2/2;
        end
        
        RR = radius(node_branch_mat(i,:));
        
        [faces_tmp, vertices_tmp, soma_volume, tmp_tot_branch_volume] = make_soma2(P, Node_Branch, RR, soma_radius, noPoints, sphericity);
        
        tot_branch_volume = tot_branch_volume + tmp_tot_branch_volume;

        faces = [faces; faces_tmp+size(vertices,1)];
        vertices = [vertices; vertices_tmp];
    else
        
        if node_degeneration(i)>1
            
            % Build Y junction
            
            P_tmp = node_mat;
            
            P = P_tmp;
            
            Node_Branch = branch_mat(node_branch_mat(i,1:node_degeneration(i)),:);
            
            branch_vec = P(Node_Branch(:,2),:) - P(Node_Branch(:,1),:);
            
            Relation = ones(1,node_degeneration(i));
            Relation(1)=0;
            

            for ii=1:node_degeneration(i)
                
                if Relation(ii)==0 && Node_Branch(ii,1)==1
                    
                    P(Node_Branch(ii,1),:) = P(Node_Branch(ii,1),:)+branch_vec(ii,:)./norm(branch_vec(ii,:)).*soma_radius.*2/2;
                    
                elseif Relation(ii)==0 && Node_Branch(ii,1)>1
                    
                    P(Node_Branch(ii,1),:) = P(Node_Branch(ii,1),:)+branch_vec(ii,:)./2;
                    
                elseif Relation(ii)==1
                    
                    P(Node_Branch(ii,2),:) = P(Node_Branch(ii,2),:)-branch_vec(ii,:)./2;
                    
                end
            end
            
            RR = radius(node_branch_mat(i,1:node_degeneration(i)));
            
            [faces_tmp, vertices_tmp, tmp_Y_junction_volume, tmp_tot_branch_volume] = Y_junction_mesh_general7(P, Node_Branch, Relation, RR, noPoints,noSectors);
            
            tot_Y_junction_volume = tot_Y_junction_volume + tmp_Y_junction_volume;
            tot_branch_volume = tot_branch_volume + tmp_tot_branch_volume;
            
            faces = [faces; faces_tmp+size(vertices,1)];
            vertices = [vertices; vertices_tmp];
            
        else
            %Close the single branch
            
            P_tmp = node_mat;
            
            P = P_tmp;
            
            Node_Branch = branch_mat(node_branch_mat(i,1),:);
            
            branch_vec = P(Node_Branch(1,2),:) - P(Node_Branch(1,1),:);
            
            Relation=0;
            
            if Node_Branch(1,1)==1
                
                P(Node_Branch(1,1),:) = P(Node_Branch(1,1),:)+branch_vec(1,:)./norm(branch_vec(1,:)).*soma_radius.*2/2;
            else
                
                P(Node_Branch(1,1),:) = P(Node_Branch(1,1),:)+branch_vec(1,:)./2;
                
            end
            
           RR = radius(node_branch_mat(i,1:node_degeneration(i)));
            
           [faces_tmp, vertices_tmp, ~, bottom_final, top_final, ~, ~, ~] = cylGen(P(Node_Branch(1,1),:),P(Node_Branch(1,2),:),RR,noPoints,noSectors,0);
           tmp = unique([bottom_final(:,:,1); top_final(:,:,end)],'row');
           DT_tmp = delaunayTriangulation(tmp);
           [~, tmp_tot_branch_volume] = convexHull(DT_tmp);
           
           tot_branch_volume = tot_branch_volume + tmp_tot_branch_volume;
               
           for kk=1:size(faces_tmp,3)
           
                faces = [faces; faces_tmp(:,:,kk)+size(vertices,1)];
                
                vertices = [vertices; vertices_tmp(:,:,kk)];
           
           end
           
           XX = [P(Node_Branch(1,2),:); top_final(1:end-1,:,end)];
           
           faces_tmp = [];
           
           for ii=1:size(top_final(1:end-1,:,end),1)
               
               faces_tmp(ii,:) = [ii+1 ii 1];
   
           end
           
           faces_tmp(ii+1,:) = [2 ii+1 1];
           
           vertices_tmp=XX;
           
           faces = [faces; faces_tmp+size(vertices,1)];
           
           vertices = [vertices; vertices_tmp];
           
           
         end
        
    end
    
end

%figure, hold on
%patch('faces', faces, 'vertices', vertices,'facecolor',[0 1 0],'edgecolor',[0 0 0],'facealpha',0.5)

plyWrite(vertices,faces,[filename '.ply']);

vertices = vertices.*1E-6;
plyWrite(vertices,faces,[filename '_IS.ply']);

%stlwrite([filename '.stl']), faces, vertices) 
swc_tree(tree,[filename '.swc']);

end