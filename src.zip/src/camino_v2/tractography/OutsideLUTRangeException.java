package tractography;

public class OutsideLUTRangeException extends Exception {
	
	public OutsideLUTRangeException(String message) {
	    super(message);
	}

    }
