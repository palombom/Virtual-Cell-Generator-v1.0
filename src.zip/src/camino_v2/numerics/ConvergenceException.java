package numerics;

public class ConvergenceException extends Exception {

    public ConvergenceException(String message) {
	super(message);

    }

}
