
function positions = initializeSpins_INSIDE_Volume_from_SWCPLY(SWCfilename,ply_filename, Nspin, fsoma, rsoma, thr)


%% Load the skeleton and the minimal mesh and output a CAMINO compatible mesh

%positions = cell(length(files),1);
%tree_tot = cell(length(files),1);
positions = zeros(Nspin,3);
    
    %[vertex,face] = read_ply([foldername PLY_fileprefix num2str(i) '_LR.ply']);
    [plyfolder,name,~] = fileparts(ply_filename);
    [V,F] = read_ply(ply_filename);
    plyWrite(V.*1e-6,F,[plyfolder '/' name '_IS.ply']);
    tree = load_tree([SWCfilename '.swc']);
    
%    soma_vol = 4./3.*pi.*(tree.D(1)./2).^3;
    
    %% Place Nspin uniformely inside the cell-mesh and set MC dynamics parameters
    
%    list_idx_C_nodes = C_tree(tree{i});
    
    [X1, X2, Y1, Y2 , Z1, Z2] = cyl_tree (tree);
    branch_vec = [X2-X1, Y2-Y1, Z2-Z1];
    branch_vec_norm = branch_vec./sqrt(dot(branch_vec,branch_vec));
    
    tmp = [X1, Y1, Z1];
    tmp = tmp + branch_vec_norm.*2/2.*rsoma;
    X1 = tmp(:,1);
    Y1 = tmp(:,2);
    Z1 = tmp(:,3);
    
    condition = sqrt(dot(branch_vec',branch_vec'))>tree.D(1)/2*2/2;
    
    n_branches = sum(condition);
    
    X1 = X1(condition==1);
    X2 = X2(condition==1);
    Y1 = Y1(condition==1);
    Y2 = Y2(condition==1);
    Z1 = Z1(condition==1);
    Z2 = Z2(condition==1);
    
    branch_vec = [X2-X1, Y2-Y1, Z2-Z1];
    
    Dbranch = tree.D(condition==1);
    
%    branch_vol = tmp(2:end);
    
%    volume_fraction = [soma_vol; branch_vol] ./ (soma_vol + sum(branch_vol));
    
    volume_fraction = [fsoma (1-fsoma)./n_branches.*ones(1,n_branches)];
    
    disp(['    Cellmodel with fsoma = ' num2str(fsoma) ', Nbranches = ' num2str(n_branches) ' of individual volume fraction = ' num2str(volume_fraction(2))])

    count = 1;
    
    %h = waitbar(0,['Placing spins in Cell #' num2str(i)]);
         
    Ntmp = Nspin .* volume_fraction;
  
    for tt = 1:length(volume_fraction)
        
        %waitbar(tt./length(volume_fraction))
        
        % Distribute spins in cell volume

        Nplaced = 0;
        
        %h2 = waitbar(0,['Placing in branch #' num2str(tt)]);
        
        while Nplaced < Ntmp(tt)
            
            %waitbar(Nplaced./Ntmp)
            
            % Place in Soma
            if tt==1
                
                new_point = (2.*rand(1,3)-1).*tree.D(tt)./2.*thr;
                %idx = my_inSph([tree.X(tt) tree.Y(tt) tree.Z(tt)], tree.D(tt)./2.*thr, new_point);
                idx = in_polyhedron(F,V,new_point);
                
                if idx==1
                    
                    positions(count,:) = new_point;
                    
                    count = count + 1;
                    
                    Nplaced = Nplaced + 1;
                    
                end
                
            end
            
            % Place in Branch
            if tt>1
                
                %new_point = [(X1(tt) - X2(tt)).*rand + X2(tt) (Y1(tt) - Y2(tt)).*rand + Y2(tt) (Z1(tt) - Z2(tt)).*rand + Z2(tt)];
                new_point = (2.*rand(1,3)-1).*Dbranch(tt-1)./2.*thr./2 + [X1(tt-1) Y1(tt-1) Z1(tt-1)] + ((0.02-0.98).*rand+0.98).*branch_vec(tt-1,:);
                %idx = my_inCyl([X1(tt-1) Y1(tt-1) Z1(tt-1)], [X2(tt-1) Y2(tt-1) Z2(tt-1)], Dbranch(tt-1)./2.*thr./2, new_point);
                idx = in_polyhedron(F,V,new_point);

                if idx==1
                    
                    positions(count,:) = new_point;
                    
                    count = count + 1;
                    
                    Nplaced = Nplaced + 1;
                    
                end
                
            end
            
        end
        
        if tt==1
            disp(['    ' num2str(round(Ntmp(tt))) ' spins displaced in the soma'])
        elseif tt==2
            disp(['    ' num2str(round(Ntmp(tt))) ' spins displaced in each branch'])
        end
        
        %close(h2)
    end
        
writeInitPositions(positions(1:Nspin,:), [SWCfilename '_InitFile.dat'])
    
    positions = positions.*1E-6;
        
writeInitPositions(positions(1:Nspin,:), [SWCfilename '_InitFile_IS.dat'])

end
