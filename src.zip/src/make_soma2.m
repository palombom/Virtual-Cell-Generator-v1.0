function [faces, vertices, soma_volume, tot_branch_volume] = make_soma2(P, Node_Branch, radius, soma_radius, noPoints, sphericity)

% Relation = 0 for Parent Branches and Relation = 1 for Daughter Branches

%% Defining the skeleton

%% Meshing the branches

n_P = size(P,1);
n_branch = size(Node_Branch,1);

geometry = struct;

tot_branch_volume = 0;

for i=1:n_branch
        
    [geometry(i).faces_final, geometry(i).vertices_final, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = test1_mod4(P(Node_Branch(i,1),:),P(Node_Branch(i,2),:),radius(i),noPoints,20,0);
    %[geometry(i).faces_final, geometry(i).vertices_final, ~, geometry(i).bottom_final, geometry(i).top_final, ~, ~, ~] = cylGen(P(Node_Branch(i,1),:),P(Node_Branch(i,2),:),radius(i),noPoints,20,0,0,0);
    
    tmp = unique([geometry(i).bottom_final(:,:,1); geometry(i).top_final(:,:,end)],'row');
    DT_tmp = delaunayTriangulation(tmp);
    [~, branch_volume] = convexHull(DT_tmp);
    tot_branch_volume = tot_branch_volume + branch_volume;
end

%% Meshing the Y junction

XX = [];

for i=1:n_branch
        
        XX = [XX; geometry(i).top_final(1:end-1,:,end)];
    
end

%    [Xs, Ys, Zs] = sphere(10);   
%    XX = [XX; soma_radius./2.*unique([Xs(:), Ys(:), Zs(:)],'row')];

   V = ParticleSampleSphere('N',50);  
   XX = [XX; soma_radius.*sphericity.*V];

   
DT=delaunayTriangulation(XX);

 [T, soma_volume] = convexHull(DT);
 Xb = DT.Points;

condition = ones(size(T,1),1);

k=1;

for i=1:n_branch
        
    interface = geometry(i).top_final(1:end-1,:,end);

    
    kini= k;
    kfin=k+size(interface,1);
    
    cc = sum(T>=kini & T<kfin,2);
    
    condition = condition & (~(cc==3));
    
    k=kfin;
    
end

vertices=Xb;
faces=T(condition,:);

end