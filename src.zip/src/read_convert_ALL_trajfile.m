function [] = read_convert_ALL_trajfile(folder)

list = dir([folder '*.traj']);

Nfiles = size(list,1);

for i=1:Nfiles
    
    read_convert_trajfile([folder list(i).name]);
    
end

end